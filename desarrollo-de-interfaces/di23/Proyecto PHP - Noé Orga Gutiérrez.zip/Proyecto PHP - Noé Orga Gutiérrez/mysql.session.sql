SELECT login FROM usuarios WHERE login = 'asdf'
