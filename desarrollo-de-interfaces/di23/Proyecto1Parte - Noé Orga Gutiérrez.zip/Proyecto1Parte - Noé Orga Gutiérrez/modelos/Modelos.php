<?php
    class Modelos {
        function __construct(){
            
            
        }
    }
?>