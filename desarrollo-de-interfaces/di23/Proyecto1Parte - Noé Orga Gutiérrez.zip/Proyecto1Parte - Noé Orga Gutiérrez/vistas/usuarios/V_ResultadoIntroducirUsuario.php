<?php
$respuesta = $respuesta['respuesta'];
echo $respuesta;
?>
