package DAO;

import model.PedidoEmpresa;

import java.util.ArrayList;

public class PedidoEmpresaDAO implements IDAO<PedidoEmpresa> {
    @Override
    public ArrayList<PedidoEmpresa> find(int id) {
        return null;
    }

    @Override
    public ArrayList<PedidoEmpresa> findAll() {
        return null;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int update(PedidoEmpresa bean) {
        return 0;
    }
}
