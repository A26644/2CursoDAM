package DAO;

import model.Juguete;

import java.util.ArrayList;

public class JugueteDAO implements IDAO<Juguete>{
    @Override
    public ArrayList<Juguete> find(int id) {
        return null;
    }

    @Override
    public ArrayList<Juguete> findAll() {
        return null;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int update(Juguete bean) {
        return 0;
    }
}
