package model;

public class DireccionFacturacion {
    private int direccionFacturacionId;
    private String nombre;

    public int getDireccionFacturacionId() {
        return direccionFacturacionId;
    }

    public void setDireccionFacturacionId(int direccionFacturacionId) {
        this.direccionFacturacionId = direccionFacturacionId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
