package model;

public class DireccionEnvio {
    private int direccoinEnvioId;
    private String nombre;

    public int getDireccoinEnvioId() {
        return direccoinEnvioId;
    }

    public void setDireccoinEnvioId(int direccoinEnvioId) {
        this.direccoinEnvioId = direccoinEnvioId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
