package model;

public class Juguete {
    private int jugueteId;
    private String jugueteNombre;
    private double juguetePrecio;
}

