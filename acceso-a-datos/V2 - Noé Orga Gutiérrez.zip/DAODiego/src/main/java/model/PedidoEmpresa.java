package model;

import java.util.Date;

public class PedidoEmpresa {
    private int pedidoEmpresaId;
    private int pedidoEmpresaEmpresaId;
    private int pedidoEmpresaNombre;
    private Date pedidoEmpresaFecha;
    private String pedidoEmpresaDireccionEnvio;
}
