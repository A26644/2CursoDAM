package sql;

public interface IMotorSQL {
    public void connect();

    public void disconnect();

}
