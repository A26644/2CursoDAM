package model;

import java.sql.Date;

public class PedidoParticular {
    private int pedidoParticularId;
    private int pedidoParticularParticularId;
    private Date pedidoParticularFecha;
}
