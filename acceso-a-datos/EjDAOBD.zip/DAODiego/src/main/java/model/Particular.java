package model;

public class Particular {
    private int particularId;
    private String particularNombre;
    private String particularApellido;
    private int particularTelefono;
    private String particularDireccion;

}
