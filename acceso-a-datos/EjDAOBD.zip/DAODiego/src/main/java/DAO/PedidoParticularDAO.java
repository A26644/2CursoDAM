package DAO;

import model.PedidoParticular;

import java.util.ArrayList;

public class PedidoParticularDAO implements IDAO<PedidoParticular>{
    @Override
    public ArrayList<PedidoParticular> find(int id) {
        return null;
    }

    @Override
    public ArrayList<PedidoParticular> findAll() {
        return null;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int update(PedidoParticular bean) {
        return 0;
    }
}
