package DAO;

import model.Particular;

import java.util.ArrayList;

public class ParticularDAO implements IDAO<Particular>{
    @Override
    public ArrayList<Particular> find(int id) {
        return null;
    }

    @Override
    public ArrayList<Particular> findAll() {
        return null;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int update(Particular bean) {
        return 0;
    }
}
