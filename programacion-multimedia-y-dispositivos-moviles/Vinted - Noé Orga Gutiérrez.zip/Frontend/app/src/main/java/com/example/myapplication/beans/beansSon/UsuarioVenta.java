package com.example.myapplication.beans.beansSon;

import com.example.myapplication.beans.Usuario;

public class UsuarioVenta extends Usuario {
    private int numeroVentas;

    public int getNumeroVentas() {
        return numeroVentas;
    }

    public void setNumeroVentas(int numeroVentas) {
        this.numeroVentas = numeroVentas;
    }
}
