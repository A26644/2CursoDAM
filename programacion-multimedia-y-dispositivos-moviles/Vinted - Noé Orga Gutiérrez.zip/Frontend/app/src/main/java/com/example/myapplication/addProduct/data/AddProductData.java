package com.example.myapplication.addProduct.data;

public class AddProductData {
    Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
