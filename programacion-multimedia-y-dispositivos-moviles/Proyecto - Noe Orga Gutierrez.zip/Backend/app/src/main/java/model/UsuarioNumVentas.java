package model;

public class UsuarioNumVentas extends Usuario {
    private Integer numeroVentas;

    public int getNumeroVentas() {
        return numeroVentas;
    }

    public void setNumeroVentas(int numeroVentas) {
        this.numeroVentas = numeroVentas;
    }

}
