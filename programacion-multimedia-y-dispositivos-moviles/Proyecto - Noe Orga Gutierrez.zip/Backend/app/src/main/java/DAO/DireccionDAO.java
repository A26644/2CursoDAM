package DAO;

import MotorSQL.MotorPostgre;

public class DireccionDAO {
    MotorPostgre motorPostgre = new MotorPostgre();

}
