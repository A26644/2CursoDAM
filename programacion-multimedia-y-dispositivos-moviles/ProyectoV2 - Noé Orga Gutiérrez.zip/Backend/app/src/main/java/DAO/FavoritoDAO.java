package DAO;

public class FavoritoDAO {

}
