package com.example.myapplication.choosingScreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.loggedScreen.view.LoggedScreenActivity;
import com.example.myapplication.login.view.ViewLoginActivity;
import com.example.myapplication.top.view.TopViewActivity;

public class ChooseUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_user);
        setHeaderFunctionality();
        initComponents();
    }
    public void initComponents(){
        Button button = findViewById(R.id.top10);
        button.setOnClickListener(e -> {
            System.out.println("Has pulsado el boton");
            Intent intent = new Intent(ChooseUserActivity.this, TopViewActivity.class);
            Bundle extras = getIntent().getExtras();
            intent.putExtra("id", extras.getInt("id"));
            startActivity(intent);
        });
    }
    public void setHeaderFunctionality() {
        TextView productoButton = findViewById(R.id.productsHeader);
        TextView userButton = findViewById(R.id.usersHeader);
        ImageView loginImage = findViewById(R.id.loginHeader);
        ImageView logoImage = findViewById(R.id.logoHeader);
        Context thisContext = ChooseUserActivity.this;

        productoButton.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ChooseProductActivity.class);
            Bundle extras = getIntent().getExtras();
            intent.putExtra("id", extras.getInt("id"));
            startActivity(intent);
        });
        userButton.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ChooseUserActivity.class);
            Bundle extras = getIntent().getExtras();
            intent.putExtra("id", extras.getInt("id"));
            startActivity(intent);
        });
        loginImage.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ViewLoginActivity.class);
            Bundle extras = getIntent().getExtras();
            intent.putExtra("id", extras.getInt("id"));
            startActivity(intent);
        });
        logoImage.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, LoggedScreenActivity.class);
            Bundle extras = getIntent().getExtras();
            intent.putExtra("id", extras.getInt("id"));
            startActivity(intent);
        });


    }

}