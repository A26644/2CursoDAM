package com.example.myapplication.loggedScreen.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.addProduct.ContractAddProduct;
import com.example.myapplication.addProduct.data.AddProductData;
import com.example.myapplication.addProduct.presenter.AddProductPresenter;
import com.example.myapplication.choosingScreen.ChooseProductActivity;
import com.example.myapplication.choosingScreen.ChooseUserActivity;
import com.example.myapplication.loggedScreen.ContractLoggedScreen;
import com.example.myapplication.loggedScreen.adapter.OnSaleDataAdapter;
import com.example.myapplication.loggedScreen.data.OnLoadSaleData;
import com.example.myapplication.loggedScreen.presenter.OnLoadSalePresenter;
import com.example.myapplication.login.view.ViewLoginActivity;

import java.util.ArrayList;

public class LoggedScreenActivity extends AppCompatActivity implements ContractLoggedScreen.View, ContractAddProduct.View {
    private OnLoadSalePresenter presenter = new OnLoadSalePresenter(this);
    private AddProductPresenter addProductPresenter = new AddProductPresenter(this);
    private static LoggedScreenActivity mainActivity = null;
    public OnSaleDataAdapter onSaleDataAdapter;
    private ArrayList<OnLoadSaleData> lstSales;
    private Integer userId;

    public static LoggedScreenActivity getInstance() {
        return mainActivity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_screen);
        initComponents();

    }

    public void initComponents() {
        setWelcomeMessageText();
        setHeaderFunctionality();
        Bundle extras = getIntent().getExtras();
        presenter.LoadOnSale(extras.getInt("id"));


    }

    private void setWelcomeMessageText() {
        TextView welcomeText = findViewById(R.id.welcomeText);
        String fullWelcomeText = "Bienvenido a Vinted";
        SpannableString spannableString = new SpannableString(fullWelcomeText);
        int startIndex = fullWelcomeText.indexOf("Vinted");
        int endIndex = startIndex + "Vinted".length();
        int color = Color.parseColor("#FF007780");
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(color);
        spannableString.setSpan(colorSpan, startIndex, endIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        welcomeText.setText(spannableString);
    }

    public void setHeaderFunctionality() {
        TextView productButton = findViewById(R.id.productsHeader);
        TextView userButton = findViewById(R.id.usersHeader);
        ImageView loginImage = findViewById(R.id.loginHeader);
        ImageView logoImage = findViewById(R.id.logoHeader);
        Context thisContext = LoggedScreenActivity.this;

        productButton.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ChooseProductActivity.class);
            Bundle extras = getIntent().getExtras();
            intent.putExtra("id", extras.getInt("id"));
            startActivity(intent);
        });
        userButton.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ChooseUserActivity.class);
            Bundle extras = getIntent().getExtras();
            intent.putExtra("id", extras.getInt("id"));
            startActivity(intent);
        });
        loginImage.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ViewLoginActivity.class);
            finish();
        });
        logoImage.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, LoggedScreenActivity.class);

        });


    }

    @Override
    public void successLoadOnSale(ArrayList<OnLoadSaleData> lstSales) {
        this.lstSales = lstSales;
        System.out.println("He traido " + lstSales.size() + " productos");
        RecyclerView recyclerView = findViewById(R.id.productRecycleView);
        onSaleDataAdapter = new OnSaleDataAdapter(this, lstSales);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(onSaleDataAdapter);


    }

    @Override
    public void failureLoadOnSale(String err) {
        Toast.makeText(LoggedScreenActivity.this, err, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSuccessAddProduct(AddProductData addProductData) {
        Toast.makeText(LoggedScreenActivity.this, "Producto correctamente añadido", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onFailureAddProduct(String err) {
        Toast.makeText(LoggedScreenActivity.this, err, Toast.LENGTH_SHORT).show();
    }
}