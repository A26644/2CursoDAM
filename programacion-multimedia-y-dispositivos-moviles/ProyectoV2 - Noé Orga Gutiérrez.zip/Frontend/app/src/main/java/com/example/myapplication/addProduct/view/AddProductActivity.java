package com.example.myapplication.addProduct.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.addProduct.ContractAddProduct;
import com.example.myapplication.addProduct.data.AddProductData;
import com.example.myapplication.addProduct.presenter.AddProductPresenter;
import com.example.myapplication.beans.Producto;
import com.example.myapplication.choosingScreen.ChooseProductActivity;
import com.example.myapplication.choosingScreen.ChooseUserActivity;
import com.example.myapplication.loggedScreen.view.LoggedScreenActivity;
import com.example.myapplication.login.view.ViewLoginActivity;

public class AddProductActivity extends AppCompatActivity implements ContractAddProduct.View {
    AddProductPresenter productPresenter = new AddProductPresenter(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        setHeaderFunctionality();
        initComponents();
    }
    public void initComponents(){
        EditText brand = findViewById(R.id.addBrand);
        EditText name = findViewById(R.id.addName);
        EditText desc = findViewById(R.id.addDesc);
        EditText color = findViewById(R.id.addColor);
        EditText state = findViewById(R.id.addState);
        EditText price = findViewById(R.id.addPrice);
        Button addProductButton = findViewById(R.id.addProductButton);

        addProductButton.setOnClickListener(e -> {
            Bundle extras = getIntent().getExtras();
            Producto producto = new Producto();
            producto.setUsuarioId(extras.getInt("id"));
            producto.setMarca(String.valueOf(brand.getText()));
            producto.setNombre(String.valueOf(name.getText()));
            producto.setDescripcion(String.valueOf(desc.getText()));
            producto.setColor(String.valueOf(color.getText()));
            producto.setEstado(String.valueOf(state.getText()));
            producto.setPrecio(Double.parseDouble(price.getText().toString()));
            System.out.println(producto.toString());
            productPresenter.addProduct(producto);
        });
    }
    public void setHeaderFunctionality() {
        TextView productoButton = findViewById(R.id.productsHeader);
        TextView userButton = findViewById(R.id.usersHeader);
        ImageView loginImage = findViewById(R.id.loginHeader);
        ImageView logoImage = findViewById(R.id.logoHeader);
        Context thisContext = AddProductActivity.this;

        productoButton.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ChooseProductActivity.class);
            startActivity(intent);
        });
        userButton.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ChooseUserActivity.class);
            startActivity(intent);
        });
        loginImage.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, ViewLoginActivity.class);
            finish();
        });
        logoImage.setOnClickListener(e -> {
            Intent intent = new Intent(thisContext, LoggedScreenActivity.class);
        });


    }

    @Override
    public void onSuccessAddProduct(AddProductData addProductData) {
        Toast.makeText(this, "Producto añadido con exito", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onFailureAddProduct(String err) {
        Toast.makeText(this, err, Toast.LENGTH_SHORT).show();

    }
}