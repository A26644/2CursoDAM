package com.example.myapplication.RateProduct.Data;

public class RateProductData {
    Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
