package MotorSQL;

public interface IMotor {
    public void connect();

    public void disconnect();

}
